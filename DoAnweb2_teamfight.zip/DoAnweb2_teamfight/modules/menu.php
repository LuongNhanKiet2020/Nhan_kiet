<div class="header_btm">
<div class="wrap">
	<div class="header_sub">
		<div class="h_menu">
			<ul>
				<li class="active"><a href="index.php">Home</a></li> |
				<li><a href="index.php?action=menshirt&page=1">Men shirts</a></li> |
				<li><a href="index.php?action=womenshirt">Women shirts</a></li> |
				<li><a href="index.php?action=menpants">men pants</a></li> |
				<li><a href="index.php?action=womenpants">Women pants</a></li> |
				<!-- <li><a href="index.php?action=login">Login</a></li> |
				<li><a href="index.php?action=register">Register</a></li> -->
				<?php 
            if(isset($_SESSION["Username"])){
                echo "<li><a href='index.php?action=info'>".$_SESSION["Username"]."</a></li> |";
                echo "<li><a href='index.php?action=logout'>Dang xuat</a></li>";
            }else{	
                echo "<li><a href='index.php?action=login'>Login</a></li> |";
                echo "<li><a href='index.php?action=register'>Register</a></li>";
            }
        ?>
			</ul>
		</div>
		<div class="top-nav">
	          <nav class="nav">	        	
	    	    <a href="#" id="w3-menu-trigger"> </a>
	                  <ul class="nav-list">
	            	        <li class="nav-item"><a class="active" href="index.html">Home</a></li>
							<li class="nav-item"><a href="sale.html">Sale</a></li>
							<li class="nav-item"><a href="handbags.html">Handbags</a></li>
							<li class="nav-item"><a href="accessories.html">Accessories</a></li>
							<li class="nav-item"><a href="shoes.html">Shoes</a></li>
							<li class="nav-item"><a href="service.html">Services</a></li>
							<li class="nav-item"><a href="contact.html">Contact</a></li>
	                 </ul>
	           <div class="nav-mobile"></div></nav>
	             
	          <div class="clear"> </div>
         </div>		  
	<div class="clear"></div>
</div>
</div>
</div>