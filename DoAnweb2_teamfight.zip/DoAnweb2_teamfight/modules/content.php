<div style="position: relative;">
<?php
    // include("modules/action.php");
    if(isset($_GET["action"])){
        switch($_GET["action"]){
            case "homepage": {
                include("modules/page/homepage.php");
                break;
            }
            case "menshirt":{
                include("modules/page/menshirt.php");
                break;
            }
            case "womenshirt":{
                include("modules/page/womenshirt.php");
                break;
            }
            case "menpants":{
                include("modules/page/menpants.php");
                break;
            }
            case "womenpants":{
                include("modules/page/womenpants.php");
                break;
            }
            case "detail":{
                include("modules/page/detailproduct.php");
                break;
            }
            case "login":{
                include("modules/page/login.php");
                break;
            }
            case "register":{
                include("modules/page/register.php");
                break;
            }
            case "logout":{
                $s= session_destroy();
               if($s == true){
                /* echo"<script>location.reload()</script>"; */
                echo "<script>window.location.href=\'index.php?action=homepage\'</script>";
               
            }
            
            break;
            }
            default: {
                include("modules/page/error.php");
            }
        }
    }else{
        include("modules/page/homepage.php");
    }
?>
</div>