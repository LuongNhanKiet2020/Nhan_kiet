
<?php 
    // function product1(){
    //     include("modules/admin/config.php");
    //     $sql = "SELECT * FROM tbl_product ORDER BY ID_Product ASC LIMIT 6";
    //     $query = $connect->query($sql);
    //     while($row=$query->fetch_array()){
    //             echo "<div class='grid1_of_3' style='width: 300px; margin: 0 2% 2% 0;'>
    //             <a style='width:250px;' href='index.php?action=detail&id=".$row["ID_Product"]."'>
    //                 <img  style='height:150px;' src='modules/image/".$row["ID_Images"].".jpg' alt=''>
    //                 <h3>".$row["Name"]."</h3>
    //                 <div class='price'>
    //                     <h4>$".$row["Selling_price"]."<span>indulge</span></h4>
    //                 </div>
    //                 <span class='b_btm'></span>
    //             </a>
    //             </div>
    //             <div class='clear'></div>";
    //     }
    // }
    function product1(){
        include("modules/admin/config.php");
        $sql =  "SELECT * FROM tbl_product ORDER BY ID_Product ASC LIMIT 3";
        $query = mysqli_query($connect,$sql);
        while($row=mysqli_fetch_array($query)){
            echo "
            <div class='grid1_of_3'>
            <a href='index.php?action=detail&id=".$row["ID_Product"]."'>
                <img src='modules/image/".$row["ID_Images"].".jpg' alt=''/>
                <h3>".$row["Name"]."</h3>
                <div class='price'>
                    <h4>$".$row["Selling_price"]."<span>indulge</span></h4>
                </div>
                <span class='b_btm'></span>
            </a>
        </div>";
        }
    }
    function product_slide(){
        include("modules/admin/config.php");
        $sql =  "SELECT * FROM tbl_product ORDER BY ID_Product ASC LIMIT 7";
        $query = mysqli_query($connect,$sql);
        while($row=mysqli_fetch_array($query)){
            echo "<div class='item' onclick='location.href='index.php?action=detail&id=".$row["ID_Product"]."';'>
			<div class='cau_left'>
				<img class='lazyOwl' data-src='modules/image/".$row["ID_Images"].".jpg' alt='Lazy Owl Image'>
			</div>
			<div class='cau_left'>
				<h4><a href='index.php?action=detail&id=".$row["ID_Product"]."'>".$row["Name"]."</a></h4>
				<a href='index.php?action=detail&id=".$row["ID_Product"]."' class='btn'>shop</a>
			</div>
		</div>";
        }
    }
?>