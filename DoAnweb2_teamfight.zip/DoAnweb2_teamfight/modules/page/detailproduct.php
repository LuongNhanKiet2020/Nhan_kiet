<div class="main_bg">
<div class="wrap">	
	<div class="main">
	<!-- start content -->
	<div class="single">
			<!-- start span1_of_1 -->
			<div class="left_content">
			<div class="span1_of_1">
				<!-- start product_slider -->
				<div class="product-view">
				    <div class="product-essential">
				        <div class="product-img-box">
				    <div class="more-views" style="float: left; position: relative;">
				        <div class="more-views-container" style="height:484px;overflow:hidden;position:relative;">
						<img src="modules/images/large/0001-2.jpg" alt="" title="" style="display: block;">
				        </div>
				    <a id="cs_up" href="#" style="position: absolute; z-index: 0; left: 20px; top: -14px; display: none;">&nbsp;</a><a id="cs_down" href="#" style="position: absolute; z-index: 0; left: 20px; top: 469px;">&nbsp;</a></div>
					<script type="text/javascript">
						var prodGallery = jQblvg.parseJSON('{"prod_1":{"main":{"orig":"modules/images/0001-2.jpg","main":"modules/images/large/0001-2.jpg","thumb":"modules/images/small/0001-2.jpg","label":""},"gallery":{"item_0":{"orig":"modules/images/0001-2.jpg","main":"modules/images/large/0001-2.jpg","thumb":"modules/images/small/0001-2.jpg","label":""},"item_1":{"orig":"modules/images/0001-1.jpg","main":"modules/images/large/0001-1.jpg","thumb":"modules/images/small/0001-1.jpg","label":""},"item_2":{"orig":"modules/images/0001-5.jpg","main":"modules/images/large/0001-5.jpg","thumb":"modules/images/small/0001-5.jpg","label":""},"item_3":{"orig":"modules/images/0001-3.jpg","main":"modules/images/large/0001-3.jpg","thumb":"modules/images/small/0001-3.jpg","label":""},"item_4":{"orig":"modules/images/0001-4.jpg","main":"modules/images/large/0001-4.jpg","thumb":"modules/images/small/0001-4.jpg","label":""}},"type":"simple","video":false}}'),
						    gallery_elmnt = jQblvg('.product-img-box'),
						    galleryObj = new Object(),
						    gallery_conf = new Object();
						    gallery_conf.moreviewitem = '<a class="cs-fancybox-thumbs" data-fancybox-group="thumb" style="width:64px;height:85px;" href=""  title="" alt=""><img src="" src_main="" width="64" height="85" title="" alt="" /></a>';
						    gallery_conf.animspeed = 200;
						jQblvg(document).ready(function() {
						    galleryObj[1] = new prodViewGalleryForm(prodGallery, 'prod_1', gallery_elmnt, gallery_conf, '.product-image', '.more-views', 'http:');
						        jQblvg('.product-image .cs-fancybox-thumbs').absoluteClick();
						    jQblvg('.cs-fancybox-thumbs').fancybox({ prevEffect : 'none', 
						                             nextEffect : 'none',
						                             closeBtn : true,
						                             arrows : true,
						                             nextClick : true, 
						                             helpers: {
						                               thumbs : {
						                                   width: 64,
						                                   height: 85,
						                                   position: 'bottom'
						                               }
						                             }
						                             });
						    jQblvg('#wrap').css('z-index', '100');
						            jQblvg('.more-views-container').elScroll({type: 'vertical', elqty: 4, btn_pos: 'border', scroll_speed: 400 });
						        
						});
						
						function initGallery(a,b,element) {
						    galleryObj[a] = new prodViewGalleryForm(prods, b, gallery_elmnt, gallery_conf, '.product-image', '.more-views', '');
						};
					</script>
				</div>
				</div>
				</div>
				<!-- end product_slider -->
			</div>
			<!-- start span1_of_1 -->
			<div class="span1_of_1_des">
				  <div class="desc1">
					<h3>Lorem Ipsum is simply dummy text </h3>
					<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
					<h5>Rs. 399</h5>
					<div class="available">
						<h4>Available Options :</h4>
						<ul>
							<li>Color:
								<select>
								<option>Silver</option>
								<option>Black</option>
								<option>Dark Black</option>
								<option>Red</option>
							</select></li>
							<li>Size:
								<select>
									<option>L</option>
									<option>XL</option>
									<option>S</option>
									<option>M</option>
								</select>
							</li>
							<li>Quality:
								<select>
									<option>1</option>
									<option>2</option>
									<option>3</option>
									<option>4</option>
									<option>5</option>
								</select>
							</li>
						</ul>
						<div class="btn_form">
							<form>
								<input type="submit" value="add to cart" title="" onclick="Muahang()">
							</form>
						</div>
						<div class="clear"></div>
					</div>
					<div class="share-desc">
						<div class="share">
							<h4>Share Product :</h4>
							<ul class="share_nav">
								<li><a href="#"><img src="modules/images/facebook.png" title="facebook"></a></li>
								<li><a href="#"><img src="modules/images/twitter.png" title="Twiiter"></a></li>
								<li><a href="#"><img src="modules/images/rss.png" title="Rss"></a></li>
								<li><a href="#"><img src="modules/images/gpluse.png" title="Google+"></a></li>
				    		</ul>
						</div>
						<div class="clear"></div>
					</div>
			   	 </div>
			   	</div>
			   	<div class="clear"></div>
		         	<!-- end tabs -->
			   	</div>
			   	<!-- start sidebar -->
					<!-- end sidebar -->
          	    <div class="clear"></div>
	       </div>	
	<!-- end content -->
	</div>
</div>
</div>