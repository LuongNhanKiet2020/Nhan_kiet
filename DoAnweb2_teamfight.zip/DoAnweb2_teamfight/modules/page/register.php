<style>
.container {
  padding: 16px;
  background-color: white;
  width:50%
}
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}
a {
  color: dodgerblue;
}
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
<div>
  <div class="container">
    <label for="user"><b>Username</b></label>
    <input type="text" placeholder="Enter Email" name="username" id="username">

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" id="psw">

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" id="psw_repeat">
    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>

    <button type="submit" onclick="dangky()" class="registerbtn">Register</button>
  </div>
  
  <div class="container signin">
    <p>Already have an account? <a href="index.php?action=login">Sign in</a>.</p>
  </div>
</div>
<script>
  function dangky(){
    var user=$('#username').val();
    var pass=$('#psw').val();
    var re_pass=$('#psw_repeat').val();
    $.post('modules/xuli/xulidk.php',{username:user,psw:pass,psw_repeat:re_pass,action:"register"},function(result){
      if(result==1){
        alert("dang ky thanh cong!");
      }
      else if(result==2){
        alert("Vui long dang ky lai!");
    } else alert(result);
    });
  }
</script>
