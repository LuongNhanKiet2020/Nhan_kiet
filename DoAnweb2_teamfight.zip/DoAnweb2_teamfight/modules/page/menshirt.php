
<div class="main_bg">
<div class="wrap">	
	<div class="main">
		<h2 class="style top">featured handbags</h2>
		<!-- start grids_of_3 -->
		<div id="content">
		<div class="grids_of_3">
			<div class="grid1_of_3">
				<a href="index.php?action=detail&id=1">
					<img src="modules/images/w_pic1.jpg" alt="">
					<h3>branded handbags</h3>
					<div class="price">
						<h4>$299<span>indulge</span></h4>
					</div>
					<span class="b_btm"></span>
				</a>
			</div>
			<div class="grid1_of_3">
				<a href="index.php?action=detail&id=1">
					<img src="modules/images/w_pic2.jpg" alt="">
					<h3>branded handbags</h3>
					<div class="price">
						<h4>$299 <span>indulge</span></h4>
					</div>
					<span class="b_btm"></span>
				</a>
			</div>
			<div class="grid1_of_3">
				<a href="index.php?action=detail&id=1">
					<img src="modules/images/w_pic3.jpg" alt="">
					<h3>branded handbags</h3>
					<div class="price">
						<h4>$299<span>indulge</span></h4>
					</div>
					<span class="b_btm"></span>
				</a>
			</div>
			<div class="clear"></div>
		</div>
		<div class="grids_of_3">
			<div class="grid1_of_3">
				<a href="index.php?action=detail&id=1">
					<img src="modules/images/w_pic4.jpg" alt="">
					<h3>branded handbags</h3>
					<div class="price">
						<h4>$299<span>indulge</span></h4>
					</div>
					<span class="b_btm"></span>
				</a>
			</div>
			<div class="grid1_of_3">
				<a href="index.php?action=detail&id=1">
					<img src="modules/images/w_pic5.jpg" alt="">
					<h3>branded handbags</h3>
					<div class="price">
						<h4>$299<span>indulge</span></h4>
					</div>
					<span class="b_btm"></span>
				</a>
			</div>
			<div class="grid1_of_3">
				<a href="index.php?action=detail&id=1">
					<img src="modules/images/w_pic6.jpg" alt="">
					<h3>branded handbags</h3>
					<div class="price">
						<h4>$299<span>indulge</span></h4>
					</div>
					<span class="b_btm"></span>
				</a>
			</div>
			<div class="clear"></div>
		</div>	
		<!-- end grids_of_3 -->
		</div>
	</div>
</div>
</div>
