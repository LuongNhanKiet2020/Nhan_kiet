<?php
    if(isset($_SESSION["Username"])){
        echo "<script> window.location=\'index.php?action=homepage\'</script>";
    }
?>
<style>
    input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}
button:hover {
  opacity: 0.8;
}
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
.imgcontainer {
  text-align: center;
  margin: 20px 0 8px 0;
  position: relative;
}
img.avatar {
  width: 20%;
  border-radius: 50%;
}
.container {
  padding: 10px;
}

span.psw {
  float: right;
  padding-top: 10px;
}

.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; 
  border: 1px solid #888;
  width: 30%;
}
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}
.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}
</style>

<div id="id01" class="modal" style="display:block;position:relative; height:680px">
  
  <div class="modal-content animate">
    <div class="imgcontainer">
      <span class="close" onclick="location.href='index.php?action=homepage'" title="Close Modal">&times;</span>
      <img src="./modules/images/avatar-373-456325.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="txtuser" id="txtuser">

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="txtpass" id="txtpass">
        
      <button type="submit" onclick="dangnhap()">Login</button>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button class="cancelbtn" onclick="location.href='index.php?action=homepage'">Cancel</button>
      <span class="psw">Forgot <a href="index.php?action=register">password?</a></span>
    </div>
  </div>
</div>
<script>
  function dangnhap(){
    var user=$("#txtuser").val();
    var pass=$("#txtpass").val();
    $.post('modules/xuli/xulidn.php',{txtuser:user,txtpass:pass,action:"login"},function(result){
      if(result==1){
        alert("Ban da dang nhap thanh cong!");
        window.location.href="index.php?action=homepage";
      }
      else if(result==2){
        alert("Sai tai khoan hoac mat khau vui long dang nhap lai!");
      }else alert("khong duoc de trong");
    });
  }
</script>
