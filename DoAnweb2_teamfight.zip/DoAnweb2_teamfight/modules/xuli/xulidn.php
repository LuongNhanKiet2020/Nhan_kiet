<?php
session_start();
function dangnhap($user,$pass){
include("../admin/config.php");
    if(isset($_POST["txtuser"]) || isset($_POST["txtpass"])){
        $user=$_POST["txtuser"];
        $pass=$_POST["txtpass"];
    if($user=="" || $pass==""){
        return 0;
    }
    $sql = "SELECT Username, pass FROM tbl_account where Username='$user' and pass='$pass'";
    $result= mysqli_query($connect,$sql);
    $row = mysqli_fetch_array($result);
    if($row){
        $_SESSION['Username']=$user;
        return 1;
        // header("Location: ../../index.php");
    }
    else return 2;
    }
}
if(isset($_POST["action"])=="login"){
    echo dangnhap($_POST["txtuser"],$_POST["txtpass"]);
    }
?>