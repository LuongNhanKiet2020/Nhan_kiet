<?php
function dangky($user,$pass){
    include("../admin/config.php");
    if(isset($_POST['username']) || isset($_POST['psw']) || isset($_POST['psw-repeat'])){
        $user=$_POST['username'];
        $pass=$_POST['psw'];
        $re_pass=$_POST['psw_repeat'];
        if($pass!=$re_pass || $user=="" || $pass=="" || $re_pass==""){
            return 2;
        }
            $result = mysqli_query($connect, "INSERT INTO `tbl_account`( `Username`, `pass`, `ID_User`, `ID_Staff`, `ID_Right`) VALUES ('$user','$pass','1','1','1')");
            if($result){
                return 1;
                header("location:../page/login.php");
            }
            else return 2;
    }
}
if(isset($_POST["action"])=="register"){
    echo dangky($_POST["username"],$_POST["psw"]);
 }

?> 